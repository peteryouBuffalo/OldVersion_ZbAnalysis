#ifndef Global_cxx
#define Global_cxx

#include "Global.h"

//Global Parameters
glob::Parameters CUTS = glob::Parameters() ;

#endif
